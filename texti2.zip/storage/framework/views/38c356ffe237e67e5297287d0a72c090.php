<nav class="absolute top-0 left-0 w-full z-10 bg-transparent md:flex-row md:flex-nowrap md:justify-start flex items-center p-4">
    <div class="w-full mx-auto items-center flex justify-between md:flex-nowrap flex-wrap md:px-10 px-4">
        <a class="text-white text-sm uppercase hidden lg:inline-block font-semibold" href="#">
            
            Hello <?php echo e(auth()->user()->name); ?>

        </a>

        
        
        <form class="md:flex hidden flex-row flex-wrap items-center lg:ml-auto">

        </form>



        <?php if(file_exists(app_path('Http/Livewire/LanguageSwitcher.php'))): ?>
            <ul class="flex-col md:flex-row list-none items-center hidden md:flex">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('language-switcher', [])->html();
} elseif ($_instance->childHasBeenRendered('3NjKc04')) {
    $componentId = $_instance->getRenderedChildComponentId('3NjKc04');
    $componentTag = $_instance->getRenderedChildComponentTagName('3NjKc04');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('3NjKc04');
} else {
    $response = \Livewire\Livewire::mount('language-switcher', []);
    $html = $response->html();
    $_instance->logRenderedChild('3NjKc04', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </ul>
        <?php endif; ?>

        
        
    </div>
</nav>
<?php /**PATH /home/profesone/Code/TextiFYI/resources/views/components/nav.blade.php ENDPATH**/ ?>