<?php echo e($slot); ?>

<?php /**PATH /home/profesone/Code/TextiFYI/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>