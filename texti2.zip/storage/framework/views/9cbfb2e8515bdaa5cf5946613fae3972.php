<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="card bg-white">
        <div class="card-header border-b border-blueGray-200">
            <div class="card-header-container">
                <h6 class="card-title">
                    <?php echo e(trans('cruds.user.title_singular')); ?>

                    <?php echo e(trans('global.list')); ?>

                </h6>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_create')): ?>
                    <a class="btn btn-indigo" href="<?php echo e(route('admin.users.create')); ?>">
                        <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.user.title_singular')); ?>

                    </a>
                <?php endif; ?>
            </div>
        </div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.index')->html();
} elseif ($_instance->childHasBeenRendered('hPNPB6A')) {
    $componentId = $_instance->getRenderedChildComponentId('hPNPB6A');
    $componentTag = $_instance->getRenderedChildComponentTagName('hPNPB6A');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hPNPB6A');
} else {
    $response = \Livewire\Livewire::mount('user.index');
    $html = $response->html();
    $_instance->logRenderedChild('hPNPB6A', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/profesone/Code/TextiFYI/resources/views/admin/user/index.blade.php ENDPATH**/ ?>