<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="card bg-blueGray-100">
        <div class="card-header">
            <div class="card-header-container">
                <h6 class="card-title">
                    <?php echo e(trans('global.view')); ?>

                    <?php echo e(trans('cruds.textResponse.title_singular')); ?>:
                    <?php echo e(trans('cruds.textResponse.fields.id')); ?>

                    <?php echo e($textResponse->id); ?>

                </h6>
            </div>
        </div>

        <div class="card-body">
            <div class="pt-3">
                <table class="table table-view">
                    <tbody class="bg-white">
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.textResponse.fields.id')); ?>

                            </th>
                            <td>
                                <?php echo e($textResponse->id); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.textResponse.fields.client')); ?>

                            </th>
                            <td>
                                <?php if($textResponse->client): ?>
                                    <span class="badge badge-relationship"><?php echo e($textResponse->client->client_name ?? ''); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.textResponse.fields.campaign')); ?>

                            </th>
                            <td>
                                <?php echo e($textResponse->campaign); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.textResponse.fields.response')); ?>

                            </th>
                            <td>
                                <?php echo e($textResponse->response); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.textResponse.fields.notes')); ?>

                            </th>
                            <td>
                                <?php echo e($textResponse->notes); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.textResponse.fields.notification_main')); ?>

                            </th>
                            <td>
                                <?php echo e($textResponse->notification_main); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.textResponse.fields.notification_01')); ?>

                            </th>
                            <td>
                                <?php echo e($textResponse->notification_01); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.textResponse.fields.keywords')); ?>

                            </th>
                            <td>
                                <?php $__currentLoopData = $textResponse->keywords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge badge-relationship"><?php echo e($entry->keyword); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.textResponse.fields.main_keyword')); ?>

                            </th>
                            <td>
                                <?php if($textResponse->mainKeyword): ?>
                                    <span class="badge badge-relationship"><?php echo e($textResponse->mainKeyword->keyword ?? ''); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.textResponse.fields.start_date')); ?>

                            </th>
                            <td>
                                <?php echo e($textResponse->start_date); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.textResponse.fields.end_date')); ?>

                            </th>
                            <td>
                                <?php echo e($textResponse->end_date); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.textResponse.fields.active')); ?>

                            </th>
                            <td>
                                <input class="disabled:opacity-50 disabled:cursor-not-allowed" type="checkbox" disabled <?php echo e($textResponse->active ? 'checked' : ''); ?>>
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.textResponse.fields.created_at')); ?>

                            </th>
                            <td>
                                <?php echo e($textResponse->created_at); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.textResponse.fields.updated_at')); ?>

                            </th>
                            <td>
                                <?php echo e($textResponse->updated_at); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.textResponse.fields.deleted_at')); ?>

                            </th>
                            <td>
                                <?php echo e($textResponse->deleted_at); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.textResponse.fields.team')); ?>

                            </th>
                            <td>
                                <?php if($textResponse->team): ?>
                                    <span class="badge badge-relationship"><?php echo e($textResponse->team->name ?? ''); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="form-group">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('text_response_edit')): ?>
                    <a href="<?php echo e(route('admin.text-responses.edit', $textResponse)); ?>" class="btn btn-indigo mr-2">
                        <?php echo e(trans('global.edit')); ?>

                    </a>
                <?php endif; ?>
                <a href="<?php echo e(route('admin.text-responses.index')); ?>" class="btn btn-secondary">
                    <?php echo e(trans('global.back')); ?>

                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/profesone/Code/TextiFYI/resources/views/admin/text-response/show.blade.php ENDPATH**/ ?>