<form wire:submit.prevent="submit" class="pt-3">

    <div class="form-group <?php echo e($errors->has('textifyiNumber.textifyi_numbers') ? 'invalid' : ''); ?>">
        <label class="form-label required" for="textifyi_numbers"><?php echo e(trans('cruds.textifyiNumber.fields.textifyi_numbers')); ?></label>
        <input class="form-control" type="text" name="textifyi_numbers" id="textifyi_numbers" required wire:model.defer="textifyiNumber.textifyi_numbers">
        <div class="validation-message">
            <?php echo e($errors->first('textifyiNumber.textifyi_numbers')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.textifyiNumber.fields.textifyi_numbers_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('textifyiNumber.used') ? 'invalid' : ''); ?>">
        <input class="form-control" type="checkbox" name="used" id="used" wire:model.defer="textifyiNumber.used">
        <label class="form-label inline ml-1" for="used"><?php echo e(trans('cruds.textifyiNumber.fields.used')); ?></label>
        <div class="validation-message">
            <?php echo e($errors->first('textifyiNumber.used')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.textifyiNumber.fields.used_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('textifyiNumber.team_id') ? 'invalid' : ''); ?>">
        <label class="form-label" for="team"><?php echo e(trans('cruds.textifyiNumber.fields.team')); ?></label>
        <?php if (isset($component)) { $__componentOriginal93dc7e40dea6cee167a9b0a1adfe85d1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93dc7e40dea6cee167a9b0a1adfe85d1 = $attributes; } ?>
<?php $component = App\View\Components\SelectList::resolve(['options' => $this->listsForFields['team']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('select-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\SelectList::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-control','id' => 'team','name' => 'team','wire:model' => 'textifyiNumber.team_id']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93dc7e40dea6cee167a9b0a1adfe85d1)): ?>
<?php $attributes = $__attributesOriginal93dc7e40dea6cee167a9b0a1adfe85d1; ?>
<?php unset($__attributesOriginal93dc7e40dea6cee167a9b0a1adfe85d1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93dc7e40dea6cee167a9b0a1adfe85d1)): ?>
<?php $component = $__componentOriginal93dc7e40dea6cee167a9b0a1adfe85d1; ?>
<?php unset($__componentOriginal93dc7e40dea6cee167a9b0a1adfe85d1); ?>
<?php endif; ?>
        <div class="validation-message">
            <?php echo e($errors->first('textifyiNumber.team_id')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.textifyiNumber.fields.team_helper')); ?>

        </div>
    </div>

    <div class="form-group">
        <button class="btn btn-indigo mr-2" type="submit">
            <?php echo e(trans('global.save')); ?>

        </button>
        <a href="<?php echo e(route('admin.textifyi-numbers.index')); ?>" class="btn btn-secondary">
            <?php echo e(trans('global.cancel')); ?>

        </a>
    </div>
</form><?php /**PATH /home/profesone/Code/TextiFYI/resources/views/livewire/textifyi-number/edit.blade.php ENDPATH**/ ?>