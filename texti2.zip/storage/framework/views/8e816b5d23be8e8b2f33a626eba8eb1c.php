<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="card bg-blueGray-100">
        <div class="card-header">
            <div class="card-header-container">
                <h6 class="card-title">
                    <?php echo e(trans('global.create')); ?>

                    <?php echo e(trans('cruds.textifyiNumber.title_singular')); ?>

                </h6>
            </div>
        </div>

        <div class="card-body">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('textifyi-number.create')->html();
} elseif ($_instance->childHasBeenRendered('u667ypo')) {
    $componentId = $_instance->getRenderedChildComponentId('u667ypo');
    $componentTag = $_instance->getRenderedChildComponentTagName('u667ypo');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('u667ypo');
} else {
    $response = \Livewire\Livewire::mount('textifyi-number.create');
    $html = $response->html();
    $_instance->logRenderedChild('u667ypo', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/profesone/Code/TextiFYI/resources/views/admin/textifyi-number/create.blade.php ENDPATH**/ ?>