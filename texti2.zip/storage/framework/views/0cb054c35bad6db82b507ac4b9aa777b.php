<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="card bg-blueGray-100">
        <div class="card-header">
            <div class="card-header-container">
                <h6 class="card-title">
                    Client:
                    <?php if($client->company_name): ?>
                        <?php echo e($client->company_name); ?>

                    <?php endif; ?>
                    <?php if($client->textiFyiNumber): ?>
                        TextiFYI #
                        <span class="badge badge-relationship"><?php echo e($client->textiFyiNumber->textifyi_numbers ?? ''); ?></span>
                    <?php endif; ?>
                </h6>
            </div>
        </div>

        <div class="card-body">
            <div class="pt-3">
                <table class="table table-view">
                    <tbody class="bg-white">
                    <tr>
                        <td>
                            Contact: <?php echo e($client->client_name); ?>

                        </td>
                        <td>
                            <?php echo e($client->main_contact_number); ?>

                        </td>
                        <td>
                            <?php echo e($client->email); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <?php echo e(trans('cruds.client.fields.default_message')); ?>:<br>
                            <?php echo e($client->default_message); ?>

                        </td>
                        <td>
                            <?php echo e(trans('cruds.client.fields.default_request_message')); ?>:<br>
                            <?php echo e($client->default_request_message); ?>

                        </td>
                        <td>
                            <?php echo e(trans('cruds.client.fields.default_zipcode_message')); ?>:<br>
                            <?php echo e($client->default_zipcode_message); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <?php echo e(trans('cruds.client.fields.email_address_response')); ?>:<br>
                            <?php echo e($client->email_address_response); ?>

                        </td>
                        <td>
                            <input class="disabled:opacity-50 disabled:cursor-not-allowed" type="checkbox" disabled <?php echo e($client->default_messages_module ? 'checked' : ''); ?>>
                            <?php echo e(trans('cruds.client.fields.default_messages_module')); ?>

                        </td>
                        <td>
                            <input class="disabled:opacity-50 disabled:cursor-not-allowed" type="checkbox" disabled <?php echo e($client->default_message_notification ? 'checked' : ''); ?>>
                            <?php echo e(trans('cruds.client.fields.default_message_notification')); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <input class="disabled:opacity-50 disabled:cursor-not-allowed" type="checkbox" disabled <?php echo e($client->default_message_response ? 'checked' : ''); ?>>
                            <?php echo e(trans('cruds.client.fields.default_message_response')); ?>

                        </td>
                        <td>
                            <input class="disabled:opacity-50 disabled:cursor-not-allowed" type="checkbox" disabled <?php echo e($client->publish_keywords_module ? 'checked' : ''); ?>>
                            <?php echo e(trans('cruds.client.fields.publish_keywords_module')); ?>

                        </td>
                        <td>
                            <input class="disabled:opacity-50 disabled:cursor-not-allowed" type="checkbox" disabled <?php echo e($client->leads_module ? 'checked' : ''); ?>>
                            <?php echo e(trans('cruds.client.fields.leads_module')); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <input class="disabled:opacity-50 disabled:cursor-not-allowed" type="checkbox" disabled <?php echo e($client->keyword_module ? 'checked' : ''); ?>>
                            <?php echo e(trans('cruds.client.fields.keyword_module')); ?>

                        </td>
                        <td>
                            <input class="disabled:opacity-50 disabled:cursor-not-allowed" type="checkbox" disabled <?php echo e($client->mls_listing_module ? 'checked' : ''); ?>>
                            <?php echo e(trans('cruds.client.fields.mls_listing_module')); ?>

                        </td>
                        <td>
                            <input class="disabled:opacity-50 disabled:cursor-not-allowed" type="checkbox" disabled <?php echo e($client->mls_agent_notification ? 'checked' : ''); ?>>
                            <?php echo e(trans('cruds.client.fields.mls_agent_notification')); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <input class="disabled:opacity-50 disabled:cursor-not-allowed" type="checkbox" disabled <?php echo e($client->tips_request_module ? 'checked' : ''); ?>>
                            <?php echo e(trans('cruds.client.fields.tips_request_module')); ?>

                        </td>
                        <td>
                            <input class="disabled:opacity-50 disabled:cursor-not-allowed" type="checkbox" disabled <?php echo e($client->zip_code_module ? 'checked' : ''); ?>>
                            <?php echo e(trans('cruds.client.fields.zip_code_module')); ?>

                        </td>
                        <td>
                            <input class="disabled:opacity-50 disabled:cursor-not-allowed" type="checkbox" disabled <?php echo e($client->default_zip_notification ? 'checked' : ''); ?>>
                            <?php echo e(trans('cruds.client.fields.default_zip_notification')); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <input class="disabled:opacity-50 disabled:cursor-not-allowed" type="checkbox" disabled <?php echo e($client->email_address_module ? 'checked' : ''); ?>>
                            <?php echo e(trans('cruds.client.fields.email_address_module')); ?>

                        </td>
                        <td>
                            <input class="disabled:opacity-50 disabled:cursor-not-allowed" type="checkbox" disabled <?php echo e($client->default_email_notification ? 'checked' : ''); ?>>
                            <?php echo e(trans('cruds.client.fields.default_email_notification')); ?>

                        </td>
                        <td>

                        </td>
                    </tr>
                    </tbody>
                </table>
                <div class="text-sm">
                    Created <?php echo e($client->updated_at); ?>

                <?php if($client->deleted_at): ?>
                    Deleted on <?php echo e($client->deleted_at); ?>

                <?php endif; ?>
                </div>
            </div>
            <div class="form-group">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client_edit')): ?>
                    <a href="<?php echo e(route('admin.clients.edit', $client)); ?>" class="btn btn-indigo mr-2">
                        <?php echo e(trans('global.edit')); ?>

                    </a>
                <?php endif; ?>
                <a href="<?php echo e(route('admin.clients.index')); ?>" class="btn btn-secondary">
                    <?php echo e(trans('global.back')); ?>

                </a>
            </div>
            <div>
                <h6 class="card-title" style="padding-top: 30px">Responses</h6>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('text-response.index',[$client->client_name])->html();
} elseif ($_instance->childHasBeenRendered('lmR0nVC')) {
    $componentId = $_instance->getRenderedChildComponentId('lmR0nVC');
    $componentTag = $_instance->getRenderedChildComponentTagName('lmR0nVC');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lmR0nVC');
} else {
    $response = \Livewire\Livewire::mount('text-response.index',[$client->client_name]);
    $html = $response->html();
    $_instance->logRenderedChild('lmR0nVC', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/profesone/Code/TextiFYI/resources/views/admin/client/show.blade.php ENDPATH**/ ?>