<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>" />
    <title><?php echo e(__('panel.site_title')); ?></title>
</head>

<body class="text-blueGray-700 bg-blueGray-800 antialiased">
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
</body>

</html><?php /**PATH /home/profesone/Code/TextiFYI/resources/views/layouts/app.blade.php ENDPATH**/ ?>