<div>
    <h6 class="text-blueGray-400 text-sm mt-3 mb-6 font-bold uppercase">
        <?php echo e(__('global.profile_information')); ?>

    </h6>

    <div class="flex flex-wrap">
        <form wire:submit.prevent="updateProfileInformation" class="w-full">
            <div class="form-group px-4">
                <label class="form-label" for="name"><?php echo e(__('global.user_name')); ?></label>
                <input class="form-control" id="name" type="text" wire:model.defer="state.name" autocomplete="name">
                <?php $__errorArgs = ['state.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group px-4">
                <label class="form-label" for="email"><?php echo e(__('global.login_email')); ?></label>
                <input class="form-control" id="email" type="text" wire:model.defer="state.email" autocomplete="email">
                <?php $__errorArgs = ['state.email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group px-4 flex items-center">
                <button class="btn btn-indigo mr-3">
                    <?php echo e(__('global.save')); ?>

                </button>

                <div x-data="{ shown: false, timeout: null }" x-init="window.livewire.find('<?php echo e($_instance->id); ?>').on('saved', () => { clearTimeout(timeout); shown = true; timeout = setTimeout(() => { shown = false }, 2000);  })" x-show.transition.out.opacity.duration.1500ms="shown" x-transition:leave.opacity.duration.1500ms class="text-sm" style="display: none;">
                    <?php echo e(__('global.saved')); ?>

                </div>

            </div>
        </form>
    </div>
</div><?php /**PATH /home/profesone/Code/TextiFYI/resources/views/livewire/update-profile-information-form.blade.php ENDPATH**/ ?>