<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="card bg-blueGray-100 lg:w-6/12">
        <div class="card-header">
            <div class="card-header-container">
                <h6 class="card-title">
                    <?php echo e(__('global.my_profile')); ?>

                </h6>
            </div>
        </div>

        <div class="card-body">
            <div class="pt-3">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('update-profile-information-form')->html();
} elseif ($_instance->childHasBeenRendered('59gcJsk')) {
    $componentId = $_instance->getRenderedChildComponentId('59gcJsk');
    $componentTag = $_instance->getRenderedChildComponentTagName('59gcJsk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('59gcJsk');
} else {
    $response = \Livewire\Livewire::mount('update-profile-information-form');
    $html = $response->html();
    $_instance->logRenderedChild('59gcJsk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                    <hr class="mt-6 border-b-1 border-blueGray-300">

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('update-password-form')->html();
} elseif ($_instance->childHasBeenRendered('vEdkjBn')) {
    $componentId = $_instance->getRenderedChildComponentId('vEdkjBn');
    $componentTag = $_instance->getRenderedChildComponentTagName('vEdkjBn');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('vEdkjBn');
} else {
    $response = \Livewire\Livewire::mount('update-password-form');
    $html = $response->html();
    $_instance->logRenderedChild('vEdkjBn', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/profesone/Code/TextiFYI/resources/views/profile/show.blade.php ENDPATH**/ ?>