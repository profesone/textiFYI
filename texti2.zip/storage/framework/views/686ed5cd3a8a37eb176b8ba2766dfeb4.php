<div>
    <div class="card-controls sm:flex">
        <div class="w-full sm:w-1/2">
            Per page:
            <select wire:model="perPage" class="form-select w-full sm:w-1/6">
                <?php $__currentLoopData = $paginationOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client_delete')): ?>
                <button class="btn btn-rose ml-3 disabled:opacity-50 disabled:cursor-not-allowed" type="button" wire:click="confirm('deleteSelected')" wire:loading.attr="disabled" <?php echo e($this->selectedCount ? '' : 'disabled'); ?>>
                    <?php echo e(__('Delete Selected')); ?>

                </button>
            <?php endif; ?>

            <?php if(file_exists(app_path('Http/Livewire/ExcelExport.php'))): ?>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('excel-export', ['model' => 'Client','format' => 'csv'])->html();
} elseif ($_instance->childHasBeenRendered('l3722736557-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3722736557-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3722736557-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3722736557-0');
} else {
    $response = \Livewire\Livewire::mount('excel-export', ['model' => 'Client','format' => 'csv']);
    $html = $response->html();
    $_instance->logRenderedChild('l3722736557-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('excel-export', ['model' => 'Client','format' => 'xlsx'])->html();
} elseif ($_instance->childHasBeenRendered('l3722736557-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l3722736557-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3722736557-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3722736557-1');
} else {
    $response = \Livewire\Livewire::mount('excel-export', ['model' => 'Client','format' => 'xlsx']);
    $html = $response->html();
    $_instance->logRenderedChild('l3722736557-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('excel-export', ['model' => 'Client','format' => 'pdf'])->html();
} elseif ($_instance->childHasBeenRendered('l3722736557-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l3722736557-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3722736557-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3722736557-2');
} else {
    $response = \Livewire\Livewire::mount('excel-export', ['model' => 'Client','format' => 'pdf']);
    $html = $response->html();
    $_instance->logRenderedChild('l3722736557-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <?php endif; ?>


            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client_create')): ?>
                <?php if (isset($component)) { $__componentOriginal187add8edbaa0bcef6ed9ef38dfaa063 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal187add8edbaa0bcef6ed9ef38dfaa063 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.csv-import','data' => ['route' => ''.e(route('admin.clients.csv.store')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('csv-import'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => ''.e(route('admin.clients.csv.store')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal187add8edbaa0bcef6ed9ef38dfaa063)): ?>
<?php $attributes = $__attributesOriginal187add8edbaa0bcef6ed9ef38dfaa063; ?>
<?php unset($__attributesOriginal187add8edbaa0bcef6ed9ef38dfaa063); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal187add8edbaa0bcef6ed9ef38dfaa063)): ?>
<?php $component = $__componentOriginal187add8edbaa0bcef6ed9ef38dfaa063; ?>
<?php unset($__componentOriginal187add8edbaa0bcef6ed9ef38dfaa063); ?>
<?php endif; ?>
            <?php endif; ?>

        </div>
        <div class="w-full sm:w-1/2 sm:text-right">
            Search:
            <input type="text" wire:model.debounce.300ms="search" class="w-full sm:w-1/3 inline-block" />
        </div>
    </div>
    <div wire:loading.delay>
        Loading...
    </div>

    <div class="overflow-hidden">
        <div class="overflow-x-auto">
            <table class="table table-index w-full">
                <thead>
                    <tr>
                        <th class="w-9">
                        </th>
                        <th class="w-28">
                            <?php echo e(trans('cruds.client.fields.id')); ?>

                            <?php echo $__env->make('components.table.sort', ['field' => 'id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </th>
                        <th>
                            <?php echo e(trans('cruds.client.fields.client_name')); ?>

                            <?php echo $__env->make('components.table.sort', ['field' => 'client_name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </th>
                        <th>
                            <?php echo e(trans('cruds.client.fields.company_name')); ?>

                            <?php echo $__env->make('components.table.sort', ['field' => 'company_name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </th>
                        <th>
                            <?php echo e(trans('cruds.client.fields.main_contact_number')); ?>

                            <?php echo $__env->make('components.table.sort', ['field' => 'main_contact_number'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </th>
                        <th>
                            <?php echo e(trans('cruds.client.fields.email')); ?>

                            <?php echo $__env->make('components.table.sort', ['field' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </th>
                        <th>
                            <?php echo e(trans('cruds.client.fields.texti_fyi_number')); ?>

                            <?php echo $__env->make('components.table.sort', ['field' => 'texti_fyi_number.textifyi_numbers'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </th>
                        <th>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <input type="checkbox" value="<?php echo e($client->id); ?>" wire:model="selected">
                            </td>
                            <td>
                                <?php echo e($client->id); ?>

                            </td>
                            <td>
                                <?php echo e($client->client_name); ?>

                            </td>
                            <td>
                                <?php echo e($client->company_name); ?>

                            </td>
                            <td>
                                <?php echo e($client->main_contact_number); ?>

                            </td>
                            <td>
                                <a class="link-light-blue" href="mailto:<?php echo e($client->email); ?>">
                                    <i class="far fa-envelope fa-fw">
                                    </i>
                                    <?php echo e($client->email); ?>

                                </a>
                            </td>
                            <td>
                                <?php if($client->textiFyiNumber): ?>
                                    <span class="badge badge-relationship"><?php echo e($client->textiFyiNumber->textifyi_numbers ?? ''); ?></span>
                                <?php else: ?>
                                    <span class="badge badge-relationship">This client has no TextiFYI Number.</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="flex justify-end">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client_show')): ?>
                                        <a class="btn btn-sm btn-info mr-2" href="<?php echo e(route('admin.clients.show', $client)); ?>">
                                            <?php echo e(trans('global.view')); ?>

                                        </a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client_edit')): ?>
                                        <a class="btn btn-sm btn-success mr-2" href="<?php echo e(route('admin.clients.edit', $client)); ?>">
                                            <?php echo e(trans('global.edit')); ?>

                                        </a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client_delete')): ?>
                                        <button class="btn btn-sm btn-rose mr-2" type="button" wire:click="confirm('delete', <?php echo e($client->id); ?>)" wire:loading.attr="disabled">
                                            <?php echo e(trans('global.delete')); ?>

                                        </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="10">No entries found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card-body">
        <div class="pt-3">
            <?php if($this->selectedCount): ?>
                <p class="text-sm leading-5">
                    <span class="font-medium">
                        <?php echo e($this->selectedCount); ?>

                    </span>
                    <?php echo e(__('Entries selected')); ?>

                </p>
            <?php endif; ?>
            <?php echo e($clients->links()); ?>

        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
    <script>
        Livewire.on('confirm', e => {
    if (!confirm("<?php echo e(trans('global.areYouSure')); ?>")) {
        return
    }
window.livewire.find('<?php echo e($_instance->id); ?>')[e.callback](...e.argv)
})
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /home/profesone/Code/TextiFYI/resources/views/livewire/client/index.blade.php ENDPATH**/ ?>