<form wire:submit.prevent="submit" class="pt-3">

    <div class="form-group <?php echo e($errors->has('textResponse.client_id') ? 'invalid' : ''); ?>">
        <label class="form-label" for="client"><?php echo e(trans('cruds.textResponse.fields.client')); ?></label>
        <?php if (isset($component)) { $__componentOriginal93dc7e40dea6cee167a9b0a1adfe85d1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93dc7e40dea6cee167a9b0a1adfe85d1 = $attributes; } ?>
<?php $component = App\View\Components\SelectList::resolve(['options' => $this->listsForFields['client']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('select-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\SelectList::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-control','id' => 'client','name' => 'client','wire:model' => 'textResponse.client_id']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93dc7e40dea6cee167a9b0a1adfe85d1)): ?>
<?php $attributes = $__attributesOriginal93dc7e40dea6cee167a9b0a1adfe85d1; ?>
<?php unset($__attributesOriginal93dc7e40dea6cee167a9b0a1adfe85d1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93dc7e40dea6cee167a9b0a1adfe85d1)): ?>
<?php $component = $__componentOriginal93dc7e40dea6cee167a9b0a1adfe85d1; ?>
<?php unset($__componentOriginal93dc7e40dea6cee167a9b0a1adfe85d1); ?>
<?php endif; ?>
        <div class="validation-message">
            <?php echo e($errors->first('textResponse.client_id')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.textResponse.fields.client_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('textResponse.campaign') ? 'invalid' : ''); ?>">
        <label class="form-label required" for="campaign"><?php echo e(trans('cruds.textResponse.fields.campaign')); ?></label>
        <input class="form-control" type="text" name="campaign" id="campaign" required wire:model.defer="textResponse.campaign">
        <div class="validation-message">
            <?php echo e($errors->first('textResponse.campaign')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.textResponse.fields.campaign_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('textResponse.response') ? 'invalid' : ''); ?>">
        <label class="form-label required" for="response"><?php echo e(trans('cruds.textResponse.fields.response')); ?></label>
        <textarea class="form-control" name="response" id="response" required wire:model.defer="textResponse.response" rows="4"></textarea>
        <div class="validation-message">
            <?php echo e($errors->first('textResponse.response')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.textResponse.fields.response_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('textResponse.notes') ? 'invalid' : ''); ?>">
        <label class="form-label" for="notes"><?php echo e(trans('cruds.textResponse.fields.notes')); ?></label>
        <textarea class="form-control" name="notes" id="notes" wire:model.defer="textResponse.notes" rows="4"></textarea>
        <div class="validation-message">
            <?php echo e($errors->first('textResponse.notes')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.textResponse.fields.notes_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('textResponse.notification_main') ? 'invalid' : ''); ?>">
        <label class="form-label" for="notification_main"><?php echo e(trans('cruds.textResponse.fields.notification_main')); ?></label>
        <input class="form-control" type="text" name="notification_main" id="notification_main" wire:model.defer="textResponse.notification_main">
        <div class="validation-message">
            <?php echo e($errors->first('textResponse.notification_main')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.textResponse.fields.notification_main_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('textResponse.notification_01') ? 'invalid' : ''); ?>">
        <label class="form-label" for="notification_01"><?php echo e(trans('cruds.textResponse.fields.notification_01')); ?></label>
        <input class="form-control" type="text" name="notification_01" id="notification_01" wire:model.defer="textResponse.notification_01">
        <div class="validation-message">
            <?php echo e($errors->first('textResponse.notification_01')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.textResponse.fields.notification_01_helper')); ?>

        </div>
    </div>
    <fieldset style="border: #0b2e13 .1em solid; padding:1em;">
        <legend>Keyword Options:</legend>
            <div class="form-group <?php echo e($errors->has('keywords') ? 'invalid' : ''); ?>">
                <label class="form-label" for="keyword-list">Current Keyword List</label>
                <?php if(empty($this->keywords)): ?>
                    <span class="badge badge-relationship"> No Keywords Selected </span>
                <?php endif; ?>
                <?php $__currentLoopData = $this->keywords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="badge badge-relationship"> <?php echo e($this->listsForFields['keywords'][$key]); ?> </span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="form-group <?php echo e($errors->has('textResponse.main_keyword_id') ? 'invalid' : ''); ?>">
                <label class="form-label required" for="main_keyword"><?php echo e(trans('cruds.textResponse.fields.main_keyword')); ?></label>
                <select class="select2 form-control" required id="main_keyword"
                   name="main_keyword"
                   wire:model="textResponse.main_keyword_id" />
                <?php if(count($this->listsForFields['keywords']) > 0): ?>
                    <?php $__currentLoopData = $this->listsForFields['keywords']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $keyword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>"><?php echo e($keyword); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </select>
                <div class="validation-message">
                    <?php echo e($errors->first('textResponse.main_keyword_id')); ?>

                </div>
                <div class="help-block">
                    <?php echo e(trans('cruds.textResponse.fields.main_keyword_helper')); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('keywords') ? 'invalid' : ''); ?>">
                <label class="form-label" for="keywords"><?php echo e(trans('cruds.textResponse.fields.keywords')); ?></label>
                <select class="form-control select2"
                    id="keywords"
                    name="keywords"
                    wire:model="keywords"
                    multiple />
                <?php if(count($this->listsForFields['keywords']) > 0): ?>
                    <?php $__currentLoopData = $this->listsForFields['keywords']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $keyword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>"><?php echo e($keyword); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </select>
                <div class="validation-message">
                    <?php echo e($errors->first('keywords')); ?>

                </div>
                <div class="help-block">
                    <?php echo e(trans('cruds.textResponse.fields.keywords_helper')); ?>

                </div>
            </div>

            <hr style="margin: 2em 0 2em 0">

            <div class="form-group ">
                <label class="form-label" for="add_keyword">Create New Keyword</label>
                <input class="form-control"
                       placeholder="In case the keyword is not in your current list."
                       type="text"
                       name="add_keyword"
                       id="add_keyword"
                       wire:model.lazy="add_keyword">
                <div class="validation-message">
                    <?php echo e($errors->first('textResponse.add_keyword')); ?>

                </div>
                <div class="help-block pb-10">

                </div>
                <button wire:click.prevent="add()" class="btn btn-indigo mr-2">
                    Add
                </button>
            </div>
    </fieldset>
    <div class="form-group <?php echo e($errors->has('textResponse.start_date') ? 'invalid' : ''); ?>">
        <label class="form-label" for="start_date"><?php echo e(trans('cruds.textResponse.fields.start_date')); ?></label>
        <?php if (isset($component)) { $__componentOriginal18b803485bba15a55a015bc6815c2018 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18b803485bba15a55a015bc6815c2018 = $attributes; } ?>
<?php $component = App\View\Components\DatePicker::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('date-picker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DatePicker::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-control','wire:model' => 'textResponse.start_date','id' => 'start_date','name' => 'start_date','picker' => 'date']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18b803485bba15a55a015bc6815c2018)): ?>
<?php $attributes = $__attributesOriginal18b803485bba15a55a015bc6815c2018; ?>
<?php unset($__attributesOriginal18b803485bba15a55a015bc6815c2018); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18b803485bba15a55a015bc6815c2018)): ?>
<?php $component = $__componentOriginal18b803485bba15a55a015bc6815c2018; ?>
<?php unset($__componentOriginal18b803485bba15a55a015bc6815c2018); ?>
<?php endif; ?>
        <div class="validation-message">
            <?php echo e($errors->first('textResponse.start_date')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.textResponse.fields.start_date_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('textResponse.end_date') ? 'invalid' : ''); ?>">
        <label class="form-label" for="end_date"><?php echo e(trans('cruds.textResponse.fields.end_date')); ?></label>
        <?php if (isset($component)) { $__componentOriginal18b803485bba15a55a015bc6815c2018 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18b803485bba15a55a015bc6815c2018 = $attributes; } ?>
<?php $component = App\View\Components\DatePicker::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('date-picker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DatePicker::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-control','wire:model' => 'textResponse.end_date','id' => 'end_date','name' => 'end_date','picker' => 'date']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18b803485bba15a55a015bc6815c2018)): ?>
<?php $attributes = $__attributesOriginal18b803485bba15a55a015bc6815c2018; ?>
<?php unset($__attributesOriginal18b803485bba15a55a015bc6815c2018); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18b803485bba15a55a015bc6815c2018)): ?>
<?php $component = $__componentOriginal18b803485bba15a55a015bc6815c2018; ?>
<?php unset($__componentOriginal18b803485bba15a55a015bc6815c2018); ?>
<?php endif; ?>
        <div class="validation-message">
            <?php echo e($errors->first('textResponse.end_date')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.textResponse.fields.end_date_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('textResponse.active') ? 'invalid' : ''); ?>">
        <input class="form-control" type="checkbox" name="active" id="active" wire:model.defer="textResponse.active">
        <label class="form-label inline ml-1" for="active"><?php echo e(trans('cruds.textResponse.fields.active')); ?></label>
        <div class="validation-message">
            <?php echo e($errors->first('textResponse.active')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.textResponse.fields.active_helper')); ?>

        </div>
    </div>

    <div class="form-group">
        <button class="btn btn-indigo mr-2" type="submit">
            <?php echo e(trans('global.save')); ?>

        </button>
        <a href="<?php echo e(route('admin.text-responses.index')); ?>" class="btn btn-secondary">
            <?php echo e(trans('global.cancel')); ?>

        </a>
    </div>
</form>
<?php /**PATH /home/profesone/Code/TextiFYI/resources/views/livewire/text-response/edit.blade.php ENDPATH**/ ?>