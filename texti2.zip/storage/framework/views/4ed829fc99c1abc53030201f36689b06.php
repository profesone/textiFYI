<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="card bg-blueGray-100">
        <div class="card-header">
            <div class="card-header-container">
                <h6 class="card-title">
                    <?php echo e(trans('global.edit')); ?>

                    <?php echo e(trans('cruds.role.title_singular')); ?>:
                    <?php echo e(trans('cruds.role.fields.id')); ?>

                    <?php echo e($role->id); ?>

                </h6>
            </div>
        </div>

        <div class="card-body">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('role.edit', [$role])->html();
} elseif ($_instance->childHasBeenRendered('peZrInn')) {
    $componentId = $_instance->getRenderedChildComponentId('peZrInn');
    $componentTag = $_instance->getRenderedChildComponentTagName('peZrInn');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('peZrInn');
} else {
    $response = \Livewire\Livewire::mount('role.edit', [$role]);
    $html = $response->html();
    $_instance->logRenderedChild('peZrInn', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/profesone/Code/TextiFYI/resources/views/admin/role/edit.blade.php ENDPATH**/ ?>