<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="flex flex-wrap">
        <div class="w-full pt-6 lg:w-64 lg:pt-0">
            <?php echo $__env->make('admin.message.nav-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="w-1 flex-grow lg:pl-4">
            <div class="card bg-white">
                <div class="card-header border-b border-blueGray-200">
                    <div class="card-header-container">
                        <h6 class="card-title">
                            <?php echo e($title); ?>

                        </h6>
                    </div>
                </div>

                <div class="overdlow-hidden">
                    <div class="overdlow-x-auto">
                        <table class="table table-messages w-full">
                            <thead>
                                <tr>
                                    <th><?php echo e(__('global.subject')); ?></th>
                                    <th><?php echo e(__('global.recipients')); ?></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="cursor-pointer" x-data="{ 'isUnread': <?php echo json_encode($conversation->is_unread, 15, 512) ?> }">
                                        <td class="p-0">
                                            <a href="<?php echo e(route('admin.messages.show', $conversation)); ?>" class="block px-4 py-2" :class="{ 'font-bold': isUnread }">
                                                <?php echo e($conversation->subject); ?>

                                            </a>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('admin.messages.show', $conversation)); ?>" class="block px-4 py-2 text-xs" :class="{ 'font-bold': isUnread }">
                                                <?php $__currentLoopData = $conversation->recipients->reject(function($user) {
                                                    return $user->id === auth()->id();
                                                    }); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($user->name); ?>

                                                    &lt;<?php echo e($user->email); ?>&gt;<?php echo e(!$loop->last ? ', ' : ''); ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </a>
                                        </td>
                                        <td class="px-4 py-2">
                                            <div class="flex justify-end">
                                                <form action="<?php echo e(route('admin.messages.destroy', $conversation)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <button class="btn btn-sm btn-rose mr-2" type="submit">
                                                        <?php echo e(__('global.delete')); ?>

                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td class="px-4 py-2"><?php echo e(__('global.you_have_no_messages')); ?></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="card-body"></div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/profesone/Code/TextiFYI/resources/views/admin/message/index.blade.php ENDPATH**/ ?>