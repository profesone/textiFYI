<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="card bg-blueGray-100">
        <div class="card-header">
            <div class="card-header-container">
                <h6 class="card-title">
                    <?php echo e(trans('global.view')); ?>

                    <?php echo e(trans('cruds.textifyiNumber.title_singular')); ?>:
                    <?php echo e(trans('cruds.textifyiNumber.fields.id')); ?>

                    <?php echo e($textifyiNumber->id); ?>

                </h6>
            </div>
        </div>

        <div class="card-body">
            <div class="pt-3">
                <table class="table table-view">
                    <tbody class="bg-white">
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.textifyiNumber.fields.id')); ?>

                            </th>
                            <td>
                                <?php echo e($textifyiNumber->id); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.textifyiNumber.fields.textifyi_numbers')); ?>

                            </th>
                            <td>
                                <?php echo e($textifyiNumber->textifyi_numbers); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.textifyiNumber.fields.used')); ?>

                            </th>
                            <td>
                                <input class="disabled:opacity-50 disabled:cursor-not-allowed" type="checkbox" disabled <?php echo e($textifyiNumber->used ? 'checked' : ''); ?>>
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.textifyiNumber.fields.created_at')); ?>

                            </th>
                            <td>
                                <?php echo e($textifyiNumber->created_at); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.textifyiNumber.fields.updated_at')); ?>

                            </th>
                            <td>
                                <?php echo e($textifyiNumber->updated_at); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.textifyiNumber.fields.deleted_at')); ?>

                            </th>
                            <td>
                                <?php echo e($textifyiNumber->deleted_at); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.textifyiNumber.fields.team')); ?>

                            </th>
                            <td>
                                <?php if($textifyiNumber->team): ?>
                                    <span class="badge badge-relationship"><?php echo e($textifyiNumber->team->name ?? ''); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="form-group">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('textifyi_number_edit')): ?>
                    <a href="<?php echo e(route('admin.textifyi-numbers.edit', $textifyiNumber)); ?>" class="btn btn-indigo mr-2">
                        <?php echo e(trans('global.edit')); ?>

                    </a>
                <?php endif; ?>
                <a href="<?php echo e(route('admin.textifyi-numbers.index')); ?>" class="btn btn-secondary">
                    <?php echo e(trans('global.back')); ?>

                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/profesone/Code/TextiFYI/resources/views/admin/textifyi-number/show.blade.php ENDPATH**/ ?>