<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="card bg-blueGray-100 lg:w-6/12">
        <div class="card-header">
            <div class="card-header-container">
                <h6 class="card-title">
                    <?php echo e(__('global.my_team')); ?>

                </h6>
            </div>
        </div>

        <div class="card-body">
            <div class="pt-3">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('team.my-team-form')->html();
} elseif ($_instance->childHasBeenRendered('HJk1hdF')) {
    $componentId = $_instance->getRenderedChildComponentId('HJk1hdF');
    $componentTag = $_instance->getRenderedChildComponentTagName('HJk1hdF');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('HJk1hdF');
} else {
    $response = \Livewire\Livewire::mount('team.my-team-form');
    $html = $response->html();
    $_instance->logRenderedChild('HJk1hdF', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/profesone/Code/TextiFYI/resources/views/admin/team/my-team.blade.php ENDPATH**/ ?>