<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="card bg-blueGray-100">
        <div class="card-header">
            <div class="card-header-container">
                <h6 class="card-title">
                    <?php echo e(trans('global.edit')); ?>

                    <?php echo e(trans('cruds.client.title_singular')); ?>:
                    <?php echo e(trans('cruds.client.fields.id')); ?>

                    <?php echo e($client->id); ?>

                </h6>
            </div>
        </div>

        <div class="card-body">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('client.edit', [$client])->html();
} elseif ($_instance->childHasBeenRendered('n21rsOG')) {
    $componentId = $_instance->getRenderedChildComponentId('n21rsOG');
    $componentTag = $_instance->getRenderedChildComponentTagName('n21rsOG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('n21rsOG');
} else {
    $response = \Livewire\Livewire::mount('client.edit', [$client]);
    $html = $response->html();
    $_instance->logRenderedChild('n21rsOG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/profesone/Code/TextiFYI/resources/views/admin/client/edit.blade.php ENDPATH**/ ?>