<div>
    <a class="text-blueGray-500 block" href="#" onclick="openDropdown(event,'<?php echo e($this->id); ?>')">
        <div class="items-center flex">
            <span class="w-12 h-12 text-sm text-pink-400 md:text-white inline-flex items-center justify-center rounded-full font-bold uppercase">
                <?php echo e($currentLanguage); ?>

            </span>
        </div>
    </a>
    <div class="hidden bg-white text-base z-50 float-left py-2 list-none text-left rounded shadow-lg min-w-48" id="<?php echo e($this->id); ?>">
        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a wire:click="changeLocale('<?php echo e($language['short_code']); ?>')" href="#" class="text-sm py-2 px-4 font-normal block w-full whitespace-nowrap bg-transparent text-blueGray-700 hover:text-indigo-600">
                <?php echo e($language['title']); ?>

            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH /home/profesone/Code/TextiFYI/resources/views/livewire/language-switcher.blade.php ENDPATH**/ ?>