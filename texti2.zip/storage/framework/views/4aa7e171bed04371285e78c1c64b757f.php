<div>
    <div class="card-controls sm:flex">
        <div class="w-full sm:w-1/2">
            Per page:
            <select wire:model="perPage" class="form-select w-full sm:w-1/6">
                <?php $__currentLoopData = $paginationOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('text_response_delete')): ?>
                <button class="btn btn-rose ml-3 disabled:opacity-50 disabled:cursor-not-allowed" type="button" wire:click="confirm('deleteSelected')" wire:loading.attr="disabled" <?php echo e($this->selectedCount ? '' : 'disabled'); ?>>
                    <?php echo e(__('Delete Selected')); ?>

                </button>
            <?php endif; ?>

            <?php if(file_exists(app_path('Http/Livewire/ExcelExport.php'))): ?>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('excel-export', ['model' => 'TextResponse','format' => 'csv'])->html();
} elseif ($_instance->childHasBeenRendered('l168223304-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l168223304-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l168223304-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l168223304-0');
} else {
    $response = \Livewire\Livewire::mount('excel-export', ['model' => 'TextResponse','format' => 'csv']);
    $html = $response->html();
    $_instance->logRenderedChild('l168223304-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('excel-export', ['model' => 'TextResponse','format' => 'xlsx'])->html();
} elseif ($_instance->childHasBeenRendered('l168223304-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l168223304-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l168223304-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l168223304-1');
} else {
    $response = \Livewire\Livewire::mount('excel-export', ['model' => 'TextResponse','format' => 'xlsx']);
    $html = $response->html();
    $_instance->logRenderedChild('l168223304-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('excel-export', ['model' => 'TextResponse','format' => 'pdf'])->html();
} elseif ($_instance->childHasBeenRendered('l168223304-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l168223304-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l168223304-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l168223304-2');
} else {
    $response = \Livewire\Livewire::mount('excel-export', ['model' => 'TextResponse','format' => 'pdf']);
    $html = $response->html();
    $_instance->logRenderedChild('l168223304-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <?php endif; ?>


            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('text_response_create')): ?>
                <?php if (isset($component)) { $__componentOriginal187add8edbaa0bcef6ed9ef38dfaa063 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal187add8edbaa0bcef6ed9ef38dfaa063 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.csv-import','data' => ['route' => ''.e(route('admin.text-responses.csv.store')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('csv-import'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => ''.e(route('admin.text-responses.csv.store')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal187add8edbaa0bcef6ed9ef38dfaa063)): ?>
<?php $attributes = $__attributesOriginal187add8edbaa0bcef6ed9ef38dfaa063; ?>
<?php unset($__attributesOriginal187add8edbaa0bcef6ed9ef38dfaa063); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal187add8edbaa0bcef6ed9ef38dfaa063)): ?>
<?php $component = $__componentOriginal187add8edbaa0bcef6ed9ef38dfaa063; ?>
<?php unset($__componentOriginal187add8edbaa0bcef6ed9ef38dfaa063); ?>
<?php endif; ?>
            <?php endif; ?>

        </div>
        <div class="w-full sm:w-1/2 sm:text-right">
            Search:
            <input type="text" wire:model.debounce.300ms="search" class="w-full sm:w-1/3 inline-block" />
        </div>
    </div>
    <div wire:loading.delay>
        Loading...
    </div>

    <div class="overflow-hidden">
        <div class="overflow-x-auto">
            <table class="table table-index w-full">
                <thead>
                    <tr>
                        <th class="w-9">
                        </th>
                        <th class="w-28">
                            <?php echo e(trans('cruds.textResponse.fields.id')); ?>

                            <?php echo $__env->make('components.table.sort', ['field' => 'id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </th>
                        <th>
                            <?php echo e(trans('cruds.textResponse.fields.client')); ?>

                            <?php echo $__env->make('components.table.sort', ['field' => 'client.client_name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </th>
                        <th>
                            <?php echo e(trans('cruds.textResponse.fields.campaign')); ?>

                            <?php echo $__env->make('components.table.sort', ['field' => 'campaign'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </th>
                        <th>
                            <?php echo e(trans('cruds.textResponse.fields.active')); ?>

                            <?php echo $__env->make('components.table.sort', ['field' => 'active'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </th>
                        <th>
                            <?php echo e(trans('cruds.textResponse.fields.response')); ?>

                            <?php echo $__env->make('components.table.sort', ['field' => 'response'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </th>
                        <th>
                            <?php echo e(trans('cruds.textResponse.fields.notification_main')); ?>

                            <?php echo $__env->make('components.table.sort', ['field' => 'notification_main'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </th>
                        <th>
                            <?php echo e(trans('cruds.textResponse.fields.notification_01')); ?>

                            <?php echo $__env->make('components.table.sort', ['field' => 'notification_01'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </th>
                        <th>
                            <?php echo e(trans('cruds.textResponse.fields.keywords')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.textResponse.fields.main_keyword')); ?>

                            <?php echo $__env->make('components.table.sort', ['field' => 'main_keyword.keyword'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </th>
                        <th>
                            <?php echo e(trans('cruds.textResponse.fields.start_date')); ?>

                            <?php echo $__env->make('components.table.sort', ['field' => 'start_date'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </th>
                        <th>
                            <?php echo e(trans('cruds.textResponse.fields.end_date')); ?>

                            <?php echo $__env->make('components.table.sort', ['field' => 'end_date'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </th>
                        <th>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $textResponses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $textResponse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <input type="checkbox" value="<?php echo e($textResponse->id); ?>" wire:model="selected">
                            </td>
                            <td>
                                <?php echo e($textResponse->id); ?>

                            </td>
                            <td>
                                <?php if($textResponse->client): ?>
                                    <span class="badge badge-relationship"><?php echo e($textResponse->client->client_name ?? ''); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($textResponse->campaign); ?>

                            </td>
                            <td>
                                <input class="disabled:opacity-50 disabled:cursor-not-allowed" type="checkbox" disabled <?php echo e($textResponse->active ? 'checked' : ''); ?>>
                            </td>
                            <td>
                                <?php echo e($textResponse->response); ?>

                            </td>
                            <td>
                                <?php echo e($textResponse->notification_main); ?>

                            </td>
                            <td>
                                <?php echo e($textResponse->notification_01); ?>

                            </td>
                            <td>
                                <?php $__currentLoopData = $textResponse->keywords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge badge-relationship"><?php echo e($entry->keyword); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <?php if($textResponse->mainKeyword): ?>
                                    <span class="badge badge-relationship"><?php echo e($textResponse->mainKeyword->keyword ?? ''); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($textResponse->start_date); ?>

                            </td>
                            <td>
                                <?php echo e($textResponse->end_date); ?>

                            </td>
                            <td>
                                <div class="flex justify-end">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('text_response_show')): ?>
                                        <a class="btn btn-sm btn-info mr-2" href="<?php echo e(route('admin.text-responses.show', $textResponse)); ?>">
                                            <?php echo e(trans('global.view')); ?>

                                        </a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('text_response_edit')): ?>
                                        <a class="btn btn-sm btn-success mr-2" href="<?php echo e(route('admin.text-responses.edit', $textResponse)); ?>">
                                            <?php echo e(trans('global.edit')); ?>

                                        </a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('text_response_delete')): ?>
                                        <button class="btn btn-sm btn-rose mr-2" type="button" wire:click="confirm('delete', <?php echo e($textResponse->id); ?>)" wire:loading.attr="disabled">
                                            <?php echo e(trans('global.delete')); ?>

                                        </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="10">No entries found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card-body">
        <div class="pt-3">
            <?php if($this->selectedCount): ?>
                <p class="text-sm leading-5">
                    <span class="font-medium">
                        <?php echo e($this->selectedCount); ?>

                    </span>
                    <?php echo e(__('Entries selected')); ?>

                </p>
            <?php endif; ?>
            <?php echo e($textResponses->links()); ?>

        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
    <script>
        Livewire.on('confirm', e => {
    if (!confirm("<?php echo e(trans('global.areYouSure')); ?>")) {
        return
    }
window.livewire.find('<?php echo e($_instance->id); ?>')[e.callback](...e.argv)
})
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /home/profesone/Code/TextiFYI/resources/views/livewire/text-response/index.blade.php ENDPATH**/ ?>