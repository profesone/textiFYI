<form wire:submit.prevent="submit" class="pt-3">

    <div class="form-group <?php echo e($errors->has('textifyiNumber.textifyi_numbers') ? 'invalid' : ''); ?>">
        <label class="form-label required" for="textifyi_numbers"><?php echo e(trans('cruds.textifyiNumber.fields.textifyi_numbers')); ?></label>
        <input class="form-control" type="tel" pattern="[0-9]{10}" name="textifyi_numbers" id="textifyi_numbers" required wire:model.defer="textifyiNumber.textifyi_numbers">
        <div class="validation-message">
            <?php echo e($errors->first('textifyiNumber.textifyi_numbers')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.textifyiNumber.fields.textifyi_numbers_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('textifyiNumber.used') ? 'invalid' : ''); ?>">
        <input class="form-control" type="checkbox" name="used" id="used" wire:model.defer="textifyiNumber.used">
        <label class="form-label inline ml-1" for="used"><?php echo e(trans('cruds.textifyiNumber.fields.used')); ?></label>
        <div class="validation-message">
            <?php echo e($errors->first('textifyiNumber.used')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.textifyiNumber.fields.used_helper')); ?>

        </div>
    </div>

    <div class="form-group">
        <button class="btn btn-indigo mr-2" type="submit">
            <?php echo e(trans('global.save')); ?>

        </button>
        <a href="<?php echo e(route('admin.textifyi-numbers.index')); ?>" class="btn btn-secondary">
            <?php echo e(trans('global.cancel')); ?>

        </a>
    </div>
</form>
<?php /**PATH /home/profesone/Code/TextiFYI/resources/views/livewire/textifyi-number/create.blade.php ENDPATH**/ ?>