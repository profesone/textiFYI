<form wire:submit.prevent="submit" class="pt-3">

    <div class="form-group <?php echo e($errors->has('keyword.keyword') ? 'invalid' : ''); ?>">
        <label class="form-label required" for="keyword"><?php echo e(trans('cruds.keyword.fields.keyword')); ?></label>
        <input class="form-control" type="text" name="keyword" id="keyword" required wire:model.defer="keyword.keyword">
        <div class="validation-message">
            <?php echo e($errors->first('keyword.keyword')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.keyword.fields.keyword_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('keyword.client_id') ? 'invalid' : ''); ?>">
        <label class="form-label required" for="client"><?php echo e(trans('cruds.keyword.fields.client')); ?></label>
        <?php if (isset($component)) { $__componentOriginal93dc7e40dea6cee167a9b0a1adfe85d1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93dc7e40dea6cee167a9b0a1adfe85d1 = $attributes; } ?>
<?php $component = App\View\Components\SelectList::resolve(['options' => $this->listsForFields['client']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('select-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\SelectList::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-control','required' => true,'id' => 'client','name' => 'client','wire:model' => 'keyword.client_id']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93dc7e40dea6cee167a9b0a1adfe85d1)): ?>
<?php $attributes = $__attributesOriginal93dc7e40dea6cee167a9b0a1adfe85d1; ?>
<?php unset($__attributesOriginal93dc7e40dea6cee167a9b0a1adfe85d1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93dc7e40dea6cee167a9b0a1adfe85d1)): ?>
<?php $component = $__componentOriginal93dc7e40dea6cee167a9b0a1adfe85d1; ?>
<?php unset($__componentOriginal93dc7e40dea6cee167a9b0a1adfe85d1); ?>
<?php endif; ?>
        <div class="validation-message">
            <?php echo e($errors->first('keyword.client_id')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.keyword.fields.client_helper')); ?>

        </div>
    </div>
    <div class="form-group <?php echo e($errors->has('keyword.team_id') ? 'invalid' : ''); ?>">
        <label class="form-label" for="team"><?php echo e(trans('cruds.keyword.fields.team')); ?></label>
        <?php if (isset($component)) { $__componentOriginal93dc7e40dea6cee167a9b0a1adfe85d1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93dc7e40dea6cee167a9b0a1adfe85d1 = $attributes; } ?>
<?php $component = App\View\Components\SelectList::resolve(['options' => $this->listsForFields['team']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('select-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\SelectList::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-control','id' => 'team','name' => 'team','wire:model' => 'keyword.team_id']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93dc7e40dea6cee167a9b0a1adfe85d1)): ?>
<?php $attributes = $__attributesOriginal93dc7e40dea6cee167a9b0a1adfe85d1; ?>
<?php unset($__attributesOriginal93dc7e40dea6cee167a9b0a1adfe85d1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93dc7e40dea6cee167a9b0a1adfe85d1)): ?>
<?php $component = $__componentOriginal93dc7e40dea6cee167a9b0a1adfe85d1; ?>
<?php unset($__componentOriginal93dc7e40dea6cee167a9b0a1adfe85d1); ?>
<?php endif; ?>
        <div class="validation-message">
            <?php echo e($errors->first('keyword.team_id')); ?>

        </div>
        <div class="help-block">
            <?php echo e(trans('cruds.keyword.fields.team_helper')); ?>

        </div>
    </div>

    <div class="form-group">
        <button class="btn btn-indigo mr-2" type="submit">
            <?php echo e(trans('global.save')); ?>

        </button>
        <a href="<?php echo e(route('admin.keywords.index')); ?>" class="btn btn-secondary">
            <?php echo e(trans('global.cancel')); ?>

        </a>
    </div>
</form><?php /**PATH /home/profesone/Code/TextiFYI/resources/views/livewire/keyword/edit.blade.php ENDPATH**/ ?>