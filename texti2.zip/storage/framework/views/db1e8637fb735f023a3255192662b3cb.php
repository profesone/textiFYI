<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="card bg-blueGray-100">
        <div class="card-header">
            <div class="card-header-container">
                <h6 class="card-title">
                    <?php echo e(trans('global.edit')); ?>

                    <?php echo e(trans('cruds.textifyiNumber.title_singular')); ?>:
                    <?php echo e(trans('cruds.textifyiNumber.fields.id')); ?>

                    <?php echo e($textifyiNumber->id); ?>

                </h6>
            </div>
        </div>

        <div class="card-body">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('textifyi-number.edit', [$textifyiNumber])->html();
} elseif ($_instance->childHasBeenRendered('WbKDVzc')) {
    $componentId = $_instance->getRenderedChildComponentId('WbKDVzc');
    $componentTag = $_instance->getRenderedChildComponentTagName('WbKDVzc');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('WbKDVzc');
} else {
    $response = \Livewire\Livewire::mount('textifyi-number.edit', [$textifyiNumber]);
    $html = $response->html();
    $_instance->logRenderedChild('WbKDVzc', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/profesone/Code/TextiFYI/resources/views/admin/textifyi-number/edit.blade.php ENDPATH**/ ?>