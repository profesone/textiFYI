<div>
    {{ auth()->user()->name }} @if($agency) : {{ $agency }} @endif
</div>
