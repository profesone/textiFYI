<?php

return [
    'site_title' => 'TextiFYI',

];
